package com.cosmicclient.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial

private const val MINECRAFT_PACKAGE = "com.mojang.minecraftpe"
private const val PREFS = "cosmic_prefs"
private const val KEY_HUD_ENABLED = "hud_enabled"

class MainActivity : AppCompatActivity() {

    private lateinit var hudSwitch: SwitchMaterial
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        hudSwitch = findViewById(R.id.hudSwitch)

        val installed = isMinecraftInstalled()
        statusText.text = if (installed) "Minecraft Bedrock detected" else "Minecraft Bedrock not found — install it first"

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        hudSwitch.isChecked = prefs.getBoolean(KEY_HUD_ENABLED, true)

        hudSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_HUD_ENABLED, checked).apply()
        }

        findViewById<TextView>(R.id.playButton).setOnClickListener {
            launchMinecraft(installed)
        }
    }

    private fun isMinecraftInstalled(): Boolean = try {
        packageManager.getPackageInfo(MINECRAFT_PACKAGE, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun launchMinecraft(installed: Boolean) {
        if (!installed) {
            // Send them to the Play Store listing instead of failing silently.
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=$MINECRAFT_PACKAGE")
                )
            )
            return
        }

        if (hudSwitch.isChecked) {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
            } else {
                Toast.makeText(this, "Allow 'display over other apps' for the PvP HUD", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        packageManager.getLaunchIntentForPackage(MINECRAFT_PACKAGE)?.let {
            startActivity(it)
        }
    }
}
