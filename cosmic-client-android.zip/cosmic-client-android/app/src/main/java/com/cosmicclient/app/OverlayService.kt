package com.cosmicclient.app

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat

private const val CHANNEL_ID = "cosmic_overlay_channel"
private const val NOTIF_ID = 1001

/**
 * Draws two small, click-through(ish) views on top of whatever app is in the
 * foreground: a center crosshair and a draggable session-timer pill. Nothing
 * here reads from or writes to Minecraft's process — it only draws on top of
 * the screen, the same mechanism used by chat-head / floating-widget apps.
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var crosshairView: View? = null
    private var hudView: View? = null
    private var seconds = 0
    private var ticker: CountDownTimer? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(NOTIF_ID, buildNotification())
        addCrosshair()
        addHud()
        startTimer()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addCrosshair() {
        val inflater = LayoutInflater.from(this)
        crosshairView = inflater.inflate(R.layout.overlay_crosshair, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER

        windowManager.addView(crosshairView, params)
    }

    private fun addHud() {
        val inflater = LayoutInflater.from(this)
        hudView = inflater.inflate(R.layout.overlay_hud, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 24
        params.y = 120

        hudView!!.findViewById<View>(R.id.closeHud).setOnClickListener { stopSelf() }
        makeDraggable(hudView!!, params)

        windowManager.addView(hudView, params)
    }

    private fun makeDraggable(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f

        view.findViewById<View>(R.id.dragHandle).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun startTimer() {
        ticker = object : CountDownTimer(Long.MAX_VALUE, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                seconds++
                val m = seconds / 60
                val s = seconds % 60
                hudView?.findViewById<TextView>(R.id.timerText)?.text =
                    String.format("%02d:%02d", m, s)
            }
            override fun onFinish() {}
        }.start()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Cosmic Client HUD", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Cosmic Client HUD is active")
            .setContentText("Tap to return to the launcher")
            .setSmallIcon(android.R.drawable.presence_online)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        ticker?.cancel()
        crosshairView?.let { windowManager.removeView(it) }
        hudView?.let { windowManager.removeView(it) }
    }
}
