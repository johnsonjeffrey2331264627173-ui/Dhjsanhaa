# Cosmic Client (Android)

A legit, no-hacks PvP launcher for Minecraft Bedrock. Two pieces:

1. **Launcher** — a branded home screen with a Play button that opens Minecraft Bedrock (or sends you to its Play Store page if it isn't installed yet).
2. **Floating HUD** — an optional overlay (Android's "draw over other apps" permission, the same one chat-head apps use) that shows a center crosshair and a draggable session timer on top of the game.

## What this does *not* do (on purpose)
Android and iOS give apps no way to read taps, clicks, or game state from inside another app without abusing Accessibility Services — the same trick real spyware and cheat tools use, and an instant ban from the Play Store. So this app never reads anything from Minecraft. The HUD only ever draws on top of the screen; it doesn't see or touch the game.

## Project structure
```
cosmic-client-android/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/cosmicclient/app/
│       │   ├── MainActivity.kt      # launcher screen + launch logic
│       │   └── OverlayService.kt    # floating crosshair + timer HUD
│       └── res/                     # layouts, colors, icons
├── build.gradle
└── settings.gradle
```

## Build it
1. Install [Android Studio](https://developer.android.com/studio) (Koala or newer).
2. `File → Open` and select the `cosmic-client-android` folder.
3. Let Gradle sync (it will pull AndroidX/Material dependencies automatically).
4. Plug in an Android phone (USB debugging on) or start an emulator with Minecraft Bedrock installed.
5. Click **Run ▶**.

To get an installable APK: `Build → Build Bundle(s) / APK(s) → Build APK(s)`.

## First run
- Tap **Play**. If the HUD toggle is on, Android will ask you to allow "display over other apps" the first time — accept it, then tap Play again.
- Minecraft Bedrock opens normally; the crosshair and timer float on top.
- Drag the timer pill by its left handle to reposition it; tap the ✕ to dismiss the HUD.

## Notes
- `applicationId` is `com.cosmicclient.app` — change it in `app/build.gradle` before publishing anywhere.
- The crosshair/timer are cosmetic only — they don't affect input, hit registration, or anything Minecraft does. That's what keeps this on the right side of "legit."
- If you want additional HUD info (like real coordinates), that has to come from **inside** the game itself via a Bedrock behavior/resource pack using the Scripting API — happy to build that as a companion piece if you want it.
